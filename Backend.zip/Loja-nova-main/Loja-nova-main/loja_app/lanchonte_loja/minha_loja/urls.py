from django.urls import path
from minha_loja import views

urlpatterns = [
    path('', views.ApiOverView, name='home'),
    path('create/', views.add_items, name='add-items'),
    path('all/', views.view_items, name='view-items'),
    path('update/<int:pk>', views.update_items, name='update-item')
]  