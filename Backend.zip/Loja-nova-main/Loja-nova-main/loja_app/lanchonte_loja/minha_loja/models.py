from django.db import models
from uuid import uuid4

# Create your models here.
class Item(models.Model):
    id = models.IntegerField(primary_key=True)
    productName = models.CharField(max_length=255)
    price = models.IntegerField()
    category = models.CharField(max_length=255)
    productImage = models.CharField(max_length=255, default='Batata')

    def __str__(self) -> str:
        return self.name